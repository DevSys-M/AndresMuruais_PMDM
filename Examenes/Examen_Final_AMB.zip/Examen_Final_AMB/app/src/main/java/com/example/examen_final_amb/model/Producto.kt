package com.example.examen_final_amb.model

data class Producto(var id: Int?=null,var price: Int?=null,var stock: Int?=null,var thumbnail: String?=null,var tittle: String?=null): java.io.Serializable